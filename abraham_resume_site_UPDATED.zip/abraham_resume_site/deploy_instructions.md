# Deployment Instructions (GitHub Pages)

1. Create a GitHub repository named `Abrahamgatluak216-collab` (or any name).
2. Upload the project files (all files and folders) to the repository root.
3. Commit and push to main branch.
4. In GitHub, go to Settings → Pages, and select the `main` branch root as the source.
5. Save — your site will be published at `https://<your-username>.github.io/<repo-name>/`
6. Optional: Add a `CNAME` or enable a custom domain.

If you prefer, you can drag-and-drop the ZIP content into the GitHub repo web UI.
